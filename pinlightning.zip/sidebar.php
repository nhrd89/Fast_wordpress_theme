<?php
/**
 * The sidebar template.
 *
 * Intentionally empty — PinLightning uses a full-width design with no sidebar.
 *
 * @package PinLightning
 * @since 1.0.0
 */
